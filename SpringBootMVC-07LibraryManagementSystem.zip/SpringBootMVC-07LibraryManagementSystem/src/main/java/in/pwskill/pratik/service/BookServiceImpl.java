package in.pwskill.pratik.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.pwskill.pratik.dao.IBookRepository;
import in.pwskill.pratik.model.Book;
@Service
public class BookServiceImpl implements IBookService {

	@Autowired
	private IBookRepository repo;
	
	@Override
	public List<Book> findAllBooks() {
		
		return StreamSupport.stream(
				repo.findAll().spliterator(), false).collect(Collectors.toList());
	}

	@Override
	public Book saveBook(Book book) {
		System.out.println("saveBook method call");
		return repo.save(book);
	}

	@Override
	public void deleteBookById(Integer id) {
		repo.deleteById(id);			
	}

	@Override
	public Optional<Book> findBookById(Integer id) {
		return repo.findById(id);
		
	}

	
	
	

	
}
