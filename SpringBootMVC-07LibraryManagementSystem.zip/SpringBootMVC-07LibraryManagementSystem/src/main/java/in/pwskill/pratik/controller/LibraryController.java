package in.pwskill.pratik.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import in.pwskill.pratik.model.Book;
import in.pwskill.pratik.service.IBookService;

@Controller
public class LibraryController {
	
	@Autowired
	private IBookService service;
	
	@GetMapping("/")
	public String showPage() {
		return "redirect:new_book";
	}
	
	@GetMapping("/disp")
	public String showAllBooks(Model model) {
		model.addAttribute("books",service.findAllBooks());
		return "books";
		
	}
	@GetMapping("/new_book")
	public String showBookCreationForm(Model model) {
		model.addAttribute("book",new Book());
		System.out.println("showookCreationForm (new_book)");
		return "new_book";
	}
	
	@PostMapping("/add")
	public String addNewBook(@ModelAttribute Book book,Model model) {
		System.out.println(book);
		service.saveBook(book); //logic for adding the book in database
		model.addAttribute("books",service.findAllBooks());
		
		return "books";
	}
	
	@GetMapping("/{id}")
	public String showBookById(@PathVariable Integer id, Model model) {
		Book book=service.findBookById(id).orElseThrow(() -> new IllegalArgumentException("Invalid book id :"+id));
		model.addAttribute("book",book);
		return "edit-book";
	}
	
	@PostMapping("/{id}/delete")
	public String deleteBookById(@PathVariable Integer id,Model model) {
		service.findBookById(id).orElseThrow(() ->new IllegalArgumentException("Invalid book id :"+ id));
		service.deleteBookById(id);
		model.addAttribute("books",service.findAllBooks());
		return "books";
	}
	
	@PostMapping("{id}/update")
	public String updateBook(@PathVariable Integer id , Model model, @ModelAttribute Book book) {
		
		service.findBookById(id).orElseThrow(() -> new IllegalArgumentException("Invalid book id ::"+id));
		service.saveBook(book);
		model.addAttribute("books", service.findAllBooks());
		return "books";
	}
}
