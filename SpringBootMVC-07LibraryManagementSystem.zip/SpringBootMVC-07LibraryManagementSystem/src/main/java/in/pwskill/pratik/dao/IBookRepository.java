package in.pwskill.pratik.dao;

import org.springframework.data.repository.CrudRepository;

import in.pwskill.pratik.model.Book;

public interface IBookRepository extends CrudRepository<Book, Integer> {

}
